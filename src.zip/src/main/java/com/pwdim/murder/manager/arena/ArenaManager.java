package com.pwdim.murder.manager.arena;

import com.pwdim.murder.Murder;
import com.pwdim.murder.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class ArenaManager {

    private static Murder plugin;

    public ArenaManager(Murder plugin){
        ArenaManager.plugin = plugin;
    }


    private final ArenaEgine arenaEgine = new ArenaEgine(plugin);
    private final Map<String, Arena> activeArenas = new HashMap<>();

    public void setupNewArena(String mapName, Consumer<Arena> callback){
        String arenaID = "arena_" + System.currentTimeMillis();

        arenaEgine.createWorldInstace(mapName, arenaID, world -> {
            Arena arena = new Arena(arenaID, mapName, world);
            activeArenas.put(arenaID, arena);
            plugin.logger("&aNova asala criada para o &eMapa "+ mapName+" &b(" + arenaID + ") ");

            if (callback != null) {
                callback.accept(arena);
            }
        });
    }

    public void finishArena(String arenaID){
        Arena arena = activeArenas.get(arenaID);
        String template = arena.getMapName();

        if (arena == null) return;

        arena.getPlayers().forEach(uuid ->{

            Player p = Bukkit.getPlayer(uuid);
            if (p != null) { p.teleport(MessageUtils.getLobby());}
        });

        arenaEgine.deleteWorldInstace(arenaID);
        activeArenas.remove(arenaID);

        setupNewArena(template, null);
    }

    public Map<String, Arena> getActiveArenas() {
        return activeArenas;
    }

    public void setupNewArena(String builds, Object o) {
    }
}
