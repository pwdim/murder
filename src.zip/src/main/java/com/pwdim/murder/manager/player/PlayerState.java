package com.pwdim.murder.manager.player;

public enum PlayerState {
    DETECTIVE, INNOCENT, MURDERER, SPECTATOR
}
